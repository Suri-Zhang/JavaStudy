package day37Feb27th;

public class GenericLinkedList<T extends Comparable<T>> extends LinkedList<T> {

    public GenericLinkedList() {
        super();
    }

}
